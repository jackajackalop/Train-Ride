TRAIN RIDE SIMULATOR
Continuously generates scenery and train environment based on travel details given by the user

INSTALLATION
1.Pygame http://www.pygame.org/download.shtml
2.Python-google-places https://github.com/slimkrazy/python-google-places
3.Geolocation-python https://github.com/slawek87/geolocation-python

RUN
1. Download all files and folders for project
2. Put music you like in the music folder (optional)
3. Run main.py

HOW TO PLAY
1. Input start and end locations
2. Adjust environment with commands
	-"set month x": changes environment based on season during given month x
	-"set speed x" or arrow keys: speeds up or slows down train
	-"set time x": changes hour of current time to x in 24 hour time
	-"help": opens instructions page